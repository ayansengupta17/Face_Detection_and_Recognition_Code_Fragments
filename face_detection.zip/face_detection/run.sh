#python ./src/face_detector3.py ./images/*
#python ./src/faces_from_video.py ./test_videos/*
python ./src/front_faces_from_video.py ./test_videos/*
