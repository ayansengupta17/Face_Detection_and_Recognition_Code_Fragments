python ./src/front_faces_from_video.py ./test_videos/*
/home/itachi3/Documents/Research/codes/torch/openface_modified/mytest.sh > report.txt
