#Working, will not use this code due to poor detection capability. Faces in group photographs are not detected. Scales can be adjusted but they either get out of range, or are too small (not generalizable).  
import sys
import dlib
from skimage import io
import cv2

detector = dlib.get_frontal_face_detector()
win = dlib.image_window()
count=0
for f in sys.argv[1:]:
    img = io.imread(f)
    
    # im=cv2.imread(f)
    # The 1 in the second argument indicates that we should upsample the image
    # 1 time.  This will make everything bigger and allow us to detect more
    # faces.
    dets,scores,idx = detector.run(img,1,1)    
    for i, d in enumerate(dets):
    	count=count+1
    	im2=img[d.left():d.right(),d.top():d.bottom()]
       
        # io.imsave(str(count)+".jpeg",im2)
        win.clear_overlay()
        win.set_image(im2)
        dlib.hit_enter_to_continue()
    	
    # win.clear_overlay()
    # win.set_image(img)
    # win.add_overlay(dets)
    # dlib.hit_enter_to_continue()
