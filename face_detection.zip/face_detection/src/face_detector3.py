import cv2
import sys
import numpy as np

#path of the haarxml file
haar_path="/home/itachi3/Documents/Research/codes/torch/workspace/face_detection/haarcascade/"
#path of the cropped images
crop_path="/home/itachi3/Documents/Research/codes/torch/workspace/face_detection/results/voila_jones_results/cropped_images"

im=np.array([],np.int32)
# face_cascade = cv2.CascadeClassifier(haar_path+'haarcascade_frontalface_alt_tree.xml')
face_cascade = cv2.CascadeClassifier(haar_path+'haarcascade_frontalface_alt.xml')
profile_cascade = cv2.CascadeClassifier(haar_path+'haarcascade_profileface.xml')
for f in sys.argv[1:]:
	img = cv2.imread(f)
	#im1=cv2.resize(img,(320,320),interpolation=cv2.INTER_CUBIC)
	# gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	# faces = face_cascade.detectMultiScale(gray, 1.3, 5)
	faces = face_cascade.detectMultiScale(image=img,scaleFactor=1.1,minNeighbors=5,minSize=(10,10))
	profiles=profile_cascade.detectMultiScale(image=img,scaleFactor=1.1,minNeighbors=5,minSize=(10,10))
	count=0
	for (x,y,w,h) in faces:
		count=count+1
		print (x,y,w,h)
		im = img[y:y+h,x:x+w]
		cv2.imwrite(f[9:-4]+str(count)+".jpg",im)
		print f[9:-4]+"profile"+str(count)+".jpg"
	for (x,y,w,h) in profiles:
		count=count+1
		print (x,y,w,h)
		im = img[y:y+h,x:x+w]
		cv2.imwrite(f[9:-4]+"profile"+str(count)+".jpg",im)
		print f[9:-4]+"profile"+str(count)+".jpg"

