import cv2
import sys
import numpy as np






#path of the haarxml file
haar_path="/home/itachi3/Documents/Research/codes/torch/workspace/face_detection/haarcascade/"
#path of the cropped images
crop_path="/home/itachi3/Documents/Research/codes/torch/workspace/face_detection/results/voila_jones_results/cropped_images"
#path of the video file
video_path="/home/itachi3/Documents/Research/codes/torch/workspace/face_detection"
#path of cropped_images to be sent to neural network
crop_path="/home/itachi3/Documents/Research/codes/torch/workspace/face_detection/cropped_images"


im=np.array([],np.int32)
# face_cascade = cv2.CascadeClassifier(haar_path+'haarcascade_frontalface_alt_tree.xml')
face_cascade = cv2.CascadeClassifier(haar_path+'haarcascade_frontalface_alt.xml')
profile_cascade = cv2.CascadeClassifier(haar_path+'haarcascade_profileface.xml')



def crop_frame(img,f,frame_count):
	#im1=cv2.resize(img,(320,320),interpolation=cv2.INTER_CUBIC)
	# gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	# faces = face_cascade.detectMultiScale(gray, 1.3, 5)
	faces = face_cascade.detectMultiScale(image=img,scaleFactor=1.1,minNeighbors=5,minSize=(10,10))
	profiles=profile_cascade.detectMultiScale(image=img,scaleFactor=1.1,minNeighbors=5,minSize=(10,10))
	count=0
	for (x,y,w,h) in faces:
		print (x,y,w,h)
		im = img[y:y+h,x:x+w]
		cv2.imwrite(crop_path+f[13:-4]+str(frame_count)+".jpg",im)
		print crop_path+f[13:-4]+"profile"+str(count)+".jpg"
	for (x,y,w,h) in profiles:
		print (x,y,w,h)
		im = img[y:y+h,x:x+w]
		cv2.imwrite(crop_path+f[13:-4]+"profile"+str(frame_count)+".jpg",im)
		print crop_path+f[13:-4]+"profile"+str(frame_count)+".jpg"





for f in sys.argv[1:]:
	frame_count=0;
	vid=cv2.VideoCapture(video_path+f[1:])
	fps = vid.get(cv2.cv.CV_CAP_PROP_FRAME_COUNT)
	print fps
	while(vid.isOpened()):
		ret,frame=vid.read()
		frame_count=frame_count+1
		print frame_count
		cv2.imshow('Obama',frame)
		if((frame_count%3)==0):
			crop_frame(frame,f,frame_count)
		if cv2.waitKey(1) & 0xFF == ord('q'):
			break
	vid.release()
	cv2.destroyAllWindows()





