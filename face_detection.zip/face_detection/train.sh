/home/itachi3/Documents/Research/codes/torch/openface_modified/mytrain.sh
